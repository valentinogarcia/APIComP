# Api-Temperatura
Momento estar trabado durante 2 dias porque en el swagger puse requesBody y contents en lugar de "requestBody" y "content". Amo swagger tirar errores es para gente con 
skill issue, lo mejor es que se tengan que dar cuenta revisando cada linea hasta ver cual es el problema.
