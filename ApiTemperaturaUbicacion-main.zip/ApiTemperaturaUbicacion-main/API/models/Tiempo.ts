export class Tiempo {
    fecha: Date;
    grados: number;

    constructor(inFecha: Date, inGrados: number){
        this.fecha = inFecha; 
        this.grados = inGrados;
    }

}